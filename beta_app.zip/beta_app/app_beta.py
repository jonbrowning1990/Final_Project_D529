# app.py
from flask import Flask, jsonify, request, render_template
import sqlite3
import os

app = Flask(__name__)

# Define the path for the SQLite database
# It will be created in the same directory as app.py
DATABASE = 'catering_sqlite.db'

# --- Database Initialization and Helper Functions ---

def get_db_connection():
    """Establishes a connection to the SQLite database."""
    conn = sqlite3.connect(DATABASE)
    # This row_factory allows accessing columns by name (e.g., row['name'])
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initializes the database schema and populates with sample data."""
    if not os.path.exists(DATABASE):
        print(f"Creating database: {DATABASE}")
    conn = get_db_connection()
    cursor = conn.cursor()

@app.route('/')
def index():
    """Renders the main menu page."""
    return render_template('menu.html')

@app.route('/order')
def order_page():
    """Renders the order form page."""
    return render_template('order.html')

@app.route('/api/menu', methods=['GET'])
def get_menu():
    """
    API endpoint to fetch all menu items, categorized.
    Returns: JSON object where keys are category names and values are lists of menu items.
    Example:
    {
        "Appetizers": [ {id: 1, name: "...", price: ...}, ... ],
        "Main Courses": [ {id: 4, name: "...", price: ...}, ... ]
    }
    """
    conn = get_db_connection()
    
    
    # Fetch all menu items

    menu_items = conn.execute('SELECT name, cost_per_item AS price, course FROM menu_items ORDER BY name').fetchall()
    
    categories = ['Appetizers','Salads','Breads','Main Dishes', 'Side Dishes','Desserts']

    # Organize menu items by category
    categorized_menu = {cat: [] for cat in categories}
    for item in menu_items:
        # Find the category name for the current item
        for cat in categories:
            if cat == item['course']:
                categorized_menu[cat].append(dict(item))
                break
    
    return jsonify(categorized_menu)

@app.route('/api/estimate', methods=['POST'])
def get_estimate():
    """
    API endpoint to calculate the price estimate based on the received order details.
    Expected request.json format:
    {
        "items": [
            {"id": 1, "quantity": 2},
            {"id": 5, "quantity": 1}
        ],
        "other_details": {
            "date": "2025-07-15",
            "time": "18:00",
            "guests": 50,
            "location": "Event Hall A",
            "eventType": "Wedding",
            "specialRequests": "Nut allergy for 2 guests."
        }
    }
    """
    order_data = request.json
    selected_items = order_data.get('items', [])
    
    total_estimate = 0.0
    conn = get_db_connection()

    try:
        for item in selected_items:
            item_name = item.get('name')
            quantity = item.get('quantity')

            if not isinstance(item_name, str) or not isinstance(quantity, int) or quantity <= 0:
                return jsonify({"error": "Invalid item name or quantity."}), 400

            # Retrieve price from the database
            cursor = conn.execute('SELECT cost_per_item AS price FROM menu_items WHERE name = ?', (item_name,))
            product = cursor.fetchone()

            if product:
                total_estimate += product['price'] * quantity
            else:
                return jsonify({"error": f"Menu item with name {name} not found."}), 404
    except Exception as e:
        # Generic error handling for database issues or unexpected data
        return jsonify({"error": f"{print(selected_items)} An error occurred during estimation: {str(e)}"}), 500
    finally:
        conn.close()

    # You could add logic here for:
    # - Discounts based on quantity/total
    # - Service fees, delivery fees based on location
    # - Tax calculation

    return jsonify({"total_estimate": round(total_estimate, 2)})

# --- Main execution block ---
if __name__ == '__main__':
    # Initialize the database when the app starts
    init_db()
    # Run the Flask development server
    # debug=True allows for automatic reloading on code changes and provides a debugger
    app.run(debug=True, port=5000)
