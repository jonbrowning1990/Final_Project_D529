README.txt

## Acknowledgements - Code suggestions provided by Google Gemini 2.5 Flash

Queries used to generate base HTML, Javascript, and Python flask code for web app:

06/29/2025

How could I design a simple web application that allows users to choose from products stored in an SQL database to produce price estimates for their orders? 

06/29/2025

I would want a web page where a customer could view a catering menu offerings (stored in SQL database) on one page, then on another they could fill out a form of questions about what they would like to order, including some questions about which menu items (sorted by appetizer, main course, salad, desert, etc.) and how many of each, in order to produce a price estimate. How would I create these pages? 

06/09/2025

How could I change the code if I want the primary key for the menu_items table to be the name and not an AUTOINCREMENT id column?